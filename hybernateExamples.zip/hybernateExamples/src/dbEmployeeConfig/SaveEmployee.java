package dbEmployeeConfig;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import bean.Employee;

public class SaveEmployee {
	public static void main(String[] args) {
		StandardServiceRegistry registry=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
	 Metadata metadata=new MetadataSources(registry).getMetadataBuilder().build();
	 
	 SessionFactory factory= metadata.getSessionFactoryBuilder().build();
	 Session session= factory.openSession();
	 
	 Transaction transaction= session.beginTransaction();
	 
	 Employee employee=  new Employee();
	 employee.setName("freddy");
	 
	 session.save(employee);
	 transaction.commit();
	 System.out.println("Successfuly Saved");
	
	 factory.close();
	 session.close();
	 
	}
}
